<style>
	.quotation {
		background-color:#f8f9fa;
		text-align:center;
		padding:50px 0px;
		
	}
	.quotation h1 {
		
	}
	
	.terms{
		font-size:16px;
		
	
	}
	.terms a {
color:white;
	}
	.site-footer a:hover {
color:#F1aAFF;
	}
	marquee a:hover{
		color:#F1aAFF;
		}
	.menu li a:hover{
		color:#F1aAFF;
	}
	.list-inline li a:hover{
		color:#F1aAFF;
	}
	marquee a{
		color:white;
	}
	
	#backtotop i {
    cursor: pointer;
    border-radius: 50px;
    color: white;
	background:#063b57;;
	padding:25px 15px;
    transition: .3s;
}
	
	
</style>
   <!--  <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="section-title">
                    <div class="title">
                        <h3 style="font-weight: 700">Few of Our Designs</h3>
                    </div>                    
                </div>
            </div>
        </div>
    </div>
	
	<section class="section-padding" style="padding: 20px;">
		<div class="container">		  
		   <section class="customer-logos slider">
			  <div class="slide"><img src="assets\images\portfolio\work\work1.jpg"></div>	
              <div class="slide"><img src="assets\images\portfolio\work\work3.jpg"></div>	
			  <div class="slide"><img src="assets\images\portfolio\work\work4.jpg"></div>	
			  <div class="slide"><img src="assets\images\portfolio\work\work5.jpg"></div>	
			  <div class="slide"><img src="assets\images\portfolio\work\work2.jpg"></div>	
		   </section>		
		</div>
    </section> -->
	
	    <!-- <div class="empty-space" style="height: 90px"></div> -->

 <section class="quotation " data-parallax="scroll"  alt="Advertising Agency in chennai ">
        
            <div class="container ">
                <div class="row">
                    <div class=" col-lg-12   ">
                        <h1 style="font-size: 40px; font-family:Montserrat; "> One Click to Get Quotation today!</h1><br>
						
						
						<a href="rfq.php" >
                          <button class="btn1"> Click Me</button>
                        </a>
                </div>
				
            </div>   
		
    </section>   
	
	
					 

 <footer id="colophon" class="site-footer"> 
	<img src="assets/images/wave2.png" class="wave ">        
        <div class="footer-widgets">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-sm-6 footer-widget widget_recent_comments">
                        <h5 class="widget-title">About Us</h5>
                       <p class="justify"style="font-size: 15px;">Baleen Media is an advertising Firm, focused on Print Media, Bus Back Panel Ads, Radio Ads, Television Ads & Internet / Social Media Promotions.</p> 
						
					 
					   <div class="terms"> 
						<a href="https://merchant.razorpay.com/policy/Okdh3pvyyIYa1z/privacy" target="blank" >privacy policy</a><br>
						<a href="https://merchant.razorpay.com/policy/Okdh3pvyyIYa1z/refund"target="blank">refund & cancellation</a><br>
						<a href="https://merchant.razorpay.com/policy/Okdh3pvyyIYa1z/terms"target="blank">terms & conditions</a><br>
					</div>                       
                    </div>
					
                    <div class="col-lg-4 col-sm-6 footer-widget widget_nav_menu">
                        <h6 class="widget-title">Services</h6>
                        <div>
                            <ul class="menu">
								<li><a href="newspaper-advertisement-agency-in-chennai.php" style="font-size: 15px;">Newspaper Ads</a></li>
								<li><a href="newspaper-advertisement-agency-in-chennai.php" style="font-size: 15px;"> Magazine Ads</a></li>
                                <li><a href="paperinsert-advertisement-agency-in-chennai.php" style="font-size: 15px;">Paper Inserts</a></li>
								<li><a href="bus-advertisement-agency-in-chennai.php" style="font-size: 15px;">Bus Back Ads</a></li>
								<li><a href="noparking-advertisement-agency-in-chennai.php" style="font-size: 15px;">NoParking Board</a></li>
								<li><a href="tv-advertisement-agency-in-chennai.php" style="font-size: 15px;" >Television Ads</a></li>
                                <li><a href="radio-advertisement-agency-in-chennai.php" style="font-size: 15px;" >Radio Advertisement</a></li>
                                <li><a href="theatre-advertisement-agency-in-chennai.php" style="font-size: 15px;" >Theatre Ads</a></li>
                                <li><a href="auto-advertisement-agency-in-chennai.php" style="font-size: 15px;" >Auto Back Ads</a></li>
                            </ul>
                        </div>
                    </div>
                   <!-- . privacy policy, refund & cancellation ,terms & conditions  -->

                    <div class="col-lg-4 col-sm-6 footer-widget widget_nav_menu">
						<h6 class="widget-title">Get Connected</h6>
						<div>
							<ul class="list-inline">
								<li class="list-inline-item">
									<a class="facebook social-icon" href="https://www.facebook.com/baleenmediaa/?ref=br_rs" title="Facebook" target="_blank"><i class=" fa-lg fa fa-facebook"></i></a>
								</li>
								<li class="list-inline-item">
									<a class="twitter social-icon" href="https://twitter.com/" title="Twitter" target="_blank"><i class=" fa-lg fa fa-twitter"></i>
									</a>
								</li>
								<li class="list-inline-item">
									<a class="instagram social-icon" href="https://www.instagram.com/baleenmediaofficial/" title="Instagram" target="_blank"><i class=" fa-lg fa fa-instagram"></i>
									</a>
								</li>
								<li class="list-inline-item">
									<a class="Whatsapp social-icon" href="https://wa.me/919566031113" title="Whatsapp" target="_blank"><i class=" fa-lg fa fa-whatsapp"></i>
									</a>
								</li>
							</ul>
						</div>
				    </div>
					<div class="col-lg-4 col-sm-6 footer-widget widget_nav_menu">
						<h6 class="widget-title">Let's Meet Up</h6>
                        <div>
                            <ul class="menu">
                                <li><i class=" fa fa-building"></i> <a href="#" style="font-size: 15px;" >Baleen Media.</a></li>
								<li><a href="#"><b>OFFICE ADDRESS</b></a></li>
								<li><i class=" fa fa-home"></i> <a href="https://g.page/baleenmedia?share">No.32, Kasthuribai Nagar,<br> 3rd cross street, <br>Adyar, Chennai - 600020.<br>(Nalli Silks Opposite)</a></li>						
                                <li><i class=" fa fa-envelope"></i> <a href="#">leenah.grace@baleenmedia.com</a></li>
                                <li><i class=" fa fa-phone"></i> <a href="#">+91 95660 31113</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6 footer-widget widget_nav_menu">
					<h6 class="widget-title">Where We are</h6>
					<p><iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15548.961649994882!2d80.2194407!3d13.0203566!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x50d624131e47e020!2sBaleen%20Media%20-%20Advertising%20Agency%20in%20Chennai!5e0!3m2!1sen!2sin!4v1613470472212!5m2!1sen!2sin" width="150" height="150" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe></p>
				</div>
				</div>
            </div>			
		</div>
		
		<div class="container">
		<div class="text-center">
		<h2 class="widget-title">  SERVICES </h2>
		</div>
		<marquee> <a href="newspaper-advertisement-agency-in-chennai.php" style="font-size: 15px;"> Newspaper & Magazine Ads, </a> 
		<a href="radio-advertisement-agency-in-chennai.php" style="font-size: 15px;"> Radio Advertisement, </a>
		<a href="tv-advertisement-agency-in-chennai.php" style="font-size: 15px;"> Television Ads, </a>
		<a href="bus-advertisement-agency-in-chennai.php" style="font-size: 15px;"> Bus Back Ads, </a>
		<a href="auto-advertisement-agency-in-chennai.php" style="font-size: 15px;"> Bus Shelter Ads, </a>
		<a href="digitalmarketing-advertisement-agency-in-chennai.php" style="font-size: 15px;"> Digital Marketing, </a>
		<a href="noparking-advertisement-agency-in-chennai.php" style="font-size: 15px;"> NoParking Board, </a>
		<a href="paperinsert-advertisement-agency-in-chennai.php" style="font-size: 15px;"> Paper Inserts, </a> 
		<a href="theatre-advertisement-agency-in-chennai.php" style="font-size: 15px;"> Hoardings, </a>
		<a href="auto-advertisement-agency-in-chennai.php" style="font-size: 15px;"> Auto Back Ads, </a>
		<a href="auto-advertisement-agency-in-chennai.php" style="font-size: 15px;"> Mobile Van Branding, </a>
		<a href="auto-advertisement-agency-in-chennai.php" style="font-size: 15px;"> Software Development, </a>
		<a href="auto-advertisement-agency-in-chennai.php" style="font-size: 15px;"> Website development, </a>
		<a href="auto-advertisement-agency-in-chennai.php" style="font-size: 15px;"> SEO, </a>
		<a href="auto-advertisement-agency-in-chennai.php" style="font-size: 15px;"> Apartment Screen Branding , </a>
		<a href="auto-advertisement-agency-in-chennai.php" style="font-size: 15px;">Lamppost Ads, </a>
		<a href="auto-advertisement-agency-in-chennai.php" style="font-size: 15px;"> Traffic Alert, </a>
		<a href="auto-advertisement-agency-in-chennai.php" style="font-size: 15px;"> Pamphlets. </a>

	  </marquee>
	  </div>
		   
        <div class="copyright-bar ">
            <div class="container">
                <div class="text-center ">
                    <p class="text-white">Copyright © 2019 Baleen Meda All Rights Reserved. </p>
                </div>
            </div>
        </div>
    </footer>

    <!--======= Back to Top =======-->
    <div id="backtotop"><i class="fa fa-lg fa-arrow-up"></i></div>

    <!-- /.backtotop -->

    <!-- JavaScript -->
    <script src="assets/js/plugin.js"></script>
    <script src="assets/js/main.js"></script>
	<script type="text/javascript">
		function Allowname(){				
		if (!contactform_new.name.value.match(/^[a-zA-Z\s]*$/) && contactform_new.name.value !="")
		{
		contactform_new.name.value="";
		contactform_new.name.focus();
		//document.getElementById("appnameErr").innerHTML = "";
		alert("you have entered invalid name");
		//$('#appnameErr').html("you have entered invalid name");
		}
		else
		{
		$('#appnameErr').html("");
		return true;
		}
		}
			
		function Allowemail(){				
		if (!contactform_new.email.value.match(/^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/) && contactform_new.email.value !="")
		{
		contactform_new.email.value="";
		contactform_new.email.focus();
		//document.getElementById("appnameErr").innerHTML = "";
		alert("you have entered invalid Email");
		//$('#appemailErr').html("you have entered invalid email");
		}
		else
		{
		$('#appemailErr').html("");
		return true;
		}
		}
		
		function Allowmessage(){				
		if (contactform_new.message.value.match(/[^a-zA-Z0-9 ]/g))
		{
		contactform_new.message.value="";
		contactform_new.message.focus();
		//document.getElementById("appnameErr").innerHTML = "";
		alert("you have entered invalid Message");
		//$('#appmessageErr').html("Message Should not contain Special Character");
		}
		else
		{
		$('#appmessageErr').html("");
		return true;
		}
		}
		function Allowmobile(){						
		if (!contactform_new.mobile.value.match(/^\d{10}$/))
		{		
		contactform_new.mobile.value="";
		contactform_new.mobile.focus();
		//document.getElementById("appnameErr").innerHTML = "";
		alert("you have entered invalid Mobile No");
		//$('#appmessageErr').html("Message Should not contain Special Character");
		}
		else
		{
		$('#appmessageErr').html("");
		return true;
		}
		}
		
		</script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.js"></script>
		<script type="text/javascript">
			$(document).ready(function(){
				$('.customer-logos').slick({
					slidesToShow: 6,
					slidesToScroll: 1,
					autoplay: true,
					autoplaySpeed: 1500,
					arrows: false,
					dots: false,
					pauseOnHover: false,
					responsive: [{
						breakpoint: 768,
						settings: {
							slidesToShow: 4
						}
					}, {
						breakpoint: 520,
						settings: {
							slidesToShow: 3
						}
					}]
				});
			});
		</script>

</body>

</html>